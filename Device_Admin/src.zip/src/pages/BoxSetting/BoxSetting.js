let list =  {
  name: 'BoxSetting',
  data () {
    return {
      starnum:0,
      radio2:1,
      starnum1:0,
    }
  },
  //组件生成时执行事件
  created:function(){
  	
	},
	//页面渲染完成事件
	mounted(){
		
	},
	//方法
	methods:{
		
	},
	//使用的组件
  components:{
		
	}
};
export default list;