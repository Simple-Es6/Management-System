<template>
  <div>
  	<div class="aditem">
  		<div class="list">
  			<div class="listTop">
  				专题数量
  			</div>
  			<div class="listBot">
  				<span>
  					今日:0
  				</span>
  				<span>
  					累计:0
  				</span>	
  			</div>
  		</div>
  		<div class="list">
  			<div class="listTop">
  				音乐数量
  			</div>
  			<div class="listBot">
  				<span>
  					今日:0
  				</span>
  				<span>
  					累计:0
  				</span>	
  			</div>
  		</div>
  		<div class="list">
  			<div class="listTop">
  				用户数量
  			</div>
  			<div class="listBot">
  				<span>
  					今日:0
  				</span>
  				<span>
  					累计:0
  				</span>	
  			</div>
  		</div>
  		<div class="list">
  			<div class="listTop">
  				音箱启动数
  			</div>
  			<div class="listBot">
  				<span>
  					今日:0
  				</span>
  				<span>
  					累计:0
  				</span>
  			</div>
  		</div>
  	</div>
  	<div class="aditem">
  		<div ref="AdPieChart1" class="pitem">
  			
  		</div>
  		<div ref="AdPieChart2" class="pitem">
  			
  		</div>
  	</div>
  </div>
</template>
<script>
import list from './AdminPage.js';
export default list;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
	@import url("./AdminPage.css");
</style>
